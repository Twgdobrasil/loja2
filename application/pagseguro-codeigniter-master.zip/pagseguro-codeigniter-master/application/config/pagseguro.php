<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['pagseguroAccount'] = 'email@dominio.com.br'; // email de acesso ao painel do pagseguro.
$config['pagseguroToken'] = 'xxxxxxxxxx'; // token do pagseguro